# Grid-A-Licious 3

Demo: [http://suprb.com/apps/gridalicious/](http://suprb.com/apps/gridalicious/)

#### Changelog

- **3.01**  
Prepending items should work just fine now + many, many bugs fixed, high and low.

- **3.0**  
Initial release